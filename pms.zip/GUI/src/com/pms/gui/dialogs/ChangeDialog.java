package com.pms.gui.dialogs;

public class ChangeDialog {
}
